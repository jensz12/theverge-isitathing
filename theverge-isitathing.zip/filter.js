$(function() {
    $("#stream_title").append("and I have no idea if that's a sex thing"); 
});